# Node.js Crash Course

These are the code examples from the [YouTube crash course](https://youtu.be/32M1al-Y6Ag). This is not a working app. It is a bunch of different examples. There are no 3rd party packages except Nodemon.

To run the simple server with the users API, run `npm start`
