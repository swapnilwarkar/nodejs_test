import os from 'os';

// userInfo()
console.log(os.userInfo());

// totalmem()
console.log(os.totalmem());

// freemem()
console.log(os.freemem());

// cpus()
console.log(os.cpus());
